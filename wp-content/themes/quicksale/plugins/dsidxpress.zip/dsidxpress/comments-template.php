<?php
// Override any themes comments template to ensure nothing appears.
?>